import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateCategoryProductJunction1777400000005 implements MigrationInterface {
  name = 'CreateCategoryProductJunction1777400000005';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE \`category_product\` (\`product_id\` int NOT NULL, \`category_id\` int NOT NULL, INDEX \`IDX_0919bf58087db45b6e72ad4e4e\` (\`product_id\`), INDEX \`IDX_3258d80899c96127f31dfaab87\` (\`category_id\`), PRIMARY KEY (\`product_id\`, \`category_id\`)) ENGINE=InnoDB`,
    );
    await queryRunner.query(
      `ALTER TABLE \`category_product\` ADD CONSTRAINT \`FK_0919bf58087db45b6e72ad4e4ee\` FOREIGN KEY (\`product_id\`) REFERENCES \`products\`(\`id\`) ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE \`category_product\` ADD CONSTRAINT \`FK_3258d80899c96127f31dfaab87b\` FOREIGN KEY (\`category_id\`) REFERENCES \`categories\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE \`category_product\` DROP FOREIGN KEY \`FK_3258d80899c96127f31dfaab87b\``,
    );
    await queryRunner.query(
      `ALTER TABLE \`category_product\` DROP FOREIGN KEY \`FK_0919bf58087db45b6e72ad4e4ee\``,
    );
    await queryRunner.query(
      `DROP INDEX \`IDX_3258d80899c96127f31dfaab87\` ON \`category_product\``,
    );
    await queryRunner.query(
      `DROP INDEX \`IDX_0919bf58087db45b6e72ad4e4e\` ON \`category_product\``,
    );
    await queryRunner.query(`DROP TABLE \`category_product\``);
  }
}
