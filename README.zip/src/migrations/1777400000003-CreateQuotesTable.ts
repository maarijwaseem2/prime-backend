import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateQuotesTable1777400000003 implements MigrationInterface {
  name = 'CreateQuotesTable1777400000003';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE \`quotes\` (\`id\` int NOT NULL AUTO_INCREMENT, \`name\` varchar(255) NOT NULL, \`email\` varchar(255) NOT NULL, \`phone\` varchar(255) NULL, \`company\` varchar(255) NULL, \`message\` text NOT NULL, \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6), INDEX \`IDX_dcab96e44e48f51b62f3af2f44\` (\`email\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX \`IDX_dcab96e44e48f51b62f3af2f44\` ON \`quotes\``,
    );
    await queryRunner.query(`DROP TABLE \`quotes\``);
  }
}
