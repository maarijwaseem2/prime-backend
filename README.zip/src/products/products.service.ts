import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { Product } from '../entities/product.entity';
import { Category } from '../entities/category.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productsRepository: Repository<Product>,
    @InjectRepository(Category)
    private categoriesRepository: Repository<Category>,
  ) {}

  async create(createProductDto: CreateProductDto) {
    const { categoryIds, ...rest } = createProductDto;
    const product = this.productsRepository.create(rest);

    if (categoryIds && categoryIds.length > 0) {
      product.categories = await this.categoriesRepository.find({
        where: { id: In(categoryIds) },
      });
    }

    return this.productsRepository.save(product);
  }

  findAll() {
    return this.productsRepository.find({ relations: ['categories'] });
  }

  async findOne(id: number) {
    const product = await this.productsRepository.findOne({
      where: { id },
      relations: ['categories'],
    });
    if (!product)
      throw new NotFoundException(`Product with ID ${id} not found`);
    return product;
  }

  async findBySlug(slug: string) {
    const product = await this.productsRepository.findOne({
      where: { slug },
      relations: ['categories'],
    });
    if (!product)
      throw new NotFoundException(`Product with slug ${slug} not found`);
    return product;
  }

  async update(id: number, updateProductDto: UpdateProductDto) {
    const { categoryIds, ...rest } = updateProductDto;
    const product = await this.findOne(id);

    Object.assign(product, rest);

    if (categoryIds) {
      product.categories = await this.categoriesRepository.find({
        where: { id: In(categoryIds) },
      });
    }

    return this.productsRepository.save(product);
  }

  async remove(id: number) {
    const product = await this.findOne(id);
    return this.productsRepository.remove(product);
  }
}
