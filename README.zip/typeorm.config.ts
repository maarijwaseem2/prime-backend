import { DataSource } from 'typeorm';
import { config } from 'dotenv';
import { Category } from './src/entities/category.entity';
import { Product } from './src/entities/product.entity';
import { User } from './src/entities/user.entity';
import { Quote } from './src/entities/quote.entity';
import { Contact } from './src/entities/contact.entity';

config(); // Load environment variables from .env file

export default new DataSource({
  type: 'mysql',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  username: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'primeLocal',
  entities: [Category, Product, User, Quote, Contact],
  migrations: ['src/migrations/*.ts'],
  synchronize: false,
});
